#### Link download termux : https://f-droid.org/repo/com.termux_117.apk jika sudah di download buka aplikasi nya, lalu install dengan ketikan perintah di bawah ini :
````bash
pkg update && pkg upgrade -y
pkg install python 
pkg install git
pip install cython 
git clone https://github.com/kenDevXD/efbe-crack 
Kartu Telkomsel  suport untuk crack Tapi rata - rata cp
jadi wajar jika tidak dapat hasil atau lama
pada saat crack, Karena rawan spam.
Rekomendasi kartu Axis, XL , Three , Indosat.
````
Jika semua sudah terinstall kalian tinggal jalankan script dengan ketikan perintah di bawah ini :
````bash
cd $HOME/efbe-crack
python efbe.py
````

#### Methode crack :
• 01 Methode free (fast crack) <br>
• 02 Methode mbasic (slow crack)<br>
• 03 Methode mobile (very slow crack)<br>
#
<details open> 
<summary> PASSWORD LIST </summary>

#### Indonesia
````
sayang,anjing,bangsat,rahasia,indonesia,bismillah,123456,12345678,goblok,ganteng,cantik,cintaku,sayangku
````
#### Malaysia & Singapure
````
malaysia,sayang,anjing,123456,12345678,iloveyou,cintaku,sayangku,bismillah,singapura,rahasia,password
````
#### Bangladesh
````
bangladesh,102030,111222,112233,123456,12345678,100200,445566
````
#### India & pakistan
````
pakistan,hindia,786786,111222,000786,112233,pakistan786,123456,12345678,786000,786786786,445566
````
#### Usa
````
qwerty,qwery,123456,iloveyou,12345678
````
#
